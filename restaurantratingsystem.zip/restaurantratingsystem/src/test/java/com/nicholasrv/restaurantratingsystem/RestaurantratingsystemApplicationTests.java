package com.nicholasrv.restaurantratingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantratingsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
