package com.nicholasrv.restaurantratingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantratingsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantratingsystemApplication.class, args);
	}

}
